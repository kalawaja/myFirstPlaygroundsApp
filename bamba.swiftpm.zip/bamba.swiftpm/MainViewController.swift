//
//  MainViewController.swift
//  bamba
//
//  Created by Ramazan on 16.08.2022.
//

import UIKit

// One more thing... To make our code more clean, let's move this view controller to seperate file!

// 1. Create View Controller class
class MainViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Let's change main view background color
        view.backgroundColor = .systemPurple
        // Yes! It's work! 🚀
        // Now you can add an UIKit view components programmatically!
        
        
    }
}
