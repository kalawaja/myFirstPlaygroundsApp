//
//  MainViewController.swift
//  bamba
//
//  Created by Ramazan on 16.08.2022.
//

import UIKit

// One more thing... To make our code more clean, let's move this view controller to seperate file!

// 1. Create View Controller class
class MainViewController: UIViewController {
    
    // Create a computed properties as a container for UIKit object
    var labelHello: UILabel = {
        let label = UILabel ()
        label.frame.origin = CGPoint(x: 0, y: 0) // It's define your view/label location in screen
        label.frame.size = CGSize(width: 200, height: 100) // It's define your view/label size
        
        label.text = "Hello World! 🌎"
        // Make the label bigger!
        label.font = UIFont.systemFont(ofSize: 30)
        return label
    }()
    
    var imageViewSwiftChallenge: UIImageView = {
        let imgView = UIImageView()
        imgView.frame.origin = CGPoint(x: 0, y: 0)
        imgView.frame.size = CGSize(width: 250, height: 250)
        imgView.image = UIImage(named: "earth")
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    var buttonClickMe: UIButton = {
        let btn = UIButton()
        btn.frame.origin = CGPoint(x: 0, y: 0)
        btn.frame.size = CGSize(width: 150, height: 50)
        btn.setTitle("Click Me!", for: .normal)
        btn.backgroundColor = .systemBlue
        // Make button edges rounded
        btn.layer.cornerRadius = 10
        return btn
    }()
    
    // Now let's add new button that can trigger move screen
    var buttonGoToSecondScreen: UIButton = {
        let btn = UIButton()
        btn.frame.origin = CGPoint(x: 0, y: 0)
        btn.frame.size = CGSize(width: 150, height: 50)
        btn.setTitle("Next Screen!", for: .normal)
        btn.backgroundColor = .systemBlue
        // Make button edges rounded
        btn.layer.cornerRadius = 10
        return btn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: Label
        labelHello.center = view.center
        labelHello.textAlignment = .center
        labelHello.textColor = .black
        
        view.addSubview(labelHello)
        
        // MARK: ImageView
        imageViewSwiftChallenge.center = view.center
        imageViewSwiftChallenge.frame.origin.y -= 150
        
        view.addSubview(imageViewSwiftChallenge)
        
        // MARK: Button
        buttonClickMe.center = view.center
        buttonClickMe.frame.origin.y += 100
        
        view.addSubview(buttonClickMe)
        
        // Adding action to the button
        buttonClickMe.addTarget(self, action: #selector(actionClickMe(_:)), for: .touchUpInside)
        
        buttonGoToSecondScreen.center = view.center
        buttonGoToSecondScreen.frame.origin.y += 160
        
        view.addSubview(buttonGoToSecondScreen)
        
        // Adding action to the button
        buttonGoToSecondScreen.addTarget(self, action: #selector(actionGoToSecondScreen(_:)), for: .touchUpInside)
    }
    
    // Function that handle user interaction
    @objc func actionGoToSecondScreen(_ sender: UIButton) {
        // Finnaly, we can push SecondViewController
        navigationController?.pushViewController(SecondViewController(), animated: true) // You may disable animation
        // Let's try!
    }
    
    @objc func actionClickMe(_ sender: UIButton) {
        print("Clicked!")
        
        let alert = UIAlertController(title: "Great!", message: "Button Clicked!", preferredStyle: .alert)
        
        let ok = UIAlertAction(title: "OK", style: .default, handler: {action in
            
        })
        alert.addAction(ok)
        
        let cancel = UIAlertAction(title: "Cancel", style: .default, handler: {action in
            
        })
        alert.addAction(cancel)
        
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
        
        
    }
}
