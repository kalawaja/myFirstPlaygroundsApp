//
//  MainViewController.swift
//  bamba
//
//  Created by Ramazan on 16.08.2022.
//

import UIKit

// One more thing... To make our code more clean, let's move this view controller to seperate file!

// 1. Create View Controller class
class MainViewController: UIViewController {
    
    // Create a computed properties as a container for UIKit object
    var labelHello: UILabel = {
        let label = UILabel ()
        label.frame.origin = CGPoint(x: 0, y: 0) // It's define your view/label location in screen
        label.frame.size = CGSize(width: 200, height: 100) // It's define your view/label size
        
        label.text = "Hello World! 🌎"
        // Make the label bigger!
        label.font = UIFont.systemFont(ofSize: 30)
        return label
    }()
    
    var imageViewSwiftChallenge: UIImageView = {
        let imgView = UIImageView()
        imgView.frame.origin = CGPoint(x: 0, y: 0)
        imgView.frame.size = CGSize(width: 250, height: 250)
        imgView.image = UIImage(named: "earth")
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: Label
        labelHello.center = view.center
        labelHello.textAlignment = .center
        labelHello.textColor = .black
        
        view.addSubview(labelHello)
        
        // MARK : ImageView
        imageViewSwiftChallenge.center = view.center
        imageViewSwiftChallenge.frame.origin.y -= 200
        
        view.addSubview(imageViewSwiftChallenge)
        
        // That's it!
        
        
    }
}
