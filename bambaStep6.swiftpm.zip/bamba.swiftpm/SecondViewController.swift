//
//  SecondViewController.swift
//  bamba
//
//  Created by Ramazan on 17.08.2022.
//

import UIKit

class SecondViewController: UIViewController {
    
    // Add some label
    var label: UILabel = {
        let label = UILabel ()
        label.frame.origin = CGPoint(x: 0, y: 0) // It's define your view/label location in screen
        label.frame.size = CGSize(width: 300, height: 100) // It's define your view/label size
        
        label.text = "Second Screen! 🐘"
        // Make the label bigger!
        label.font = UIFont.systemFont(ofSize: 40)
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        label.center = view.center
        label.addSubview(label)
        
    }
}
